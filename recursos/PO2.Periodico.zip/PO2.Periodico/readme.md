# Descripción rápida 📋

Tienes maquetar (con maquetación clásica, FLOAT) una página de periódico del estilo de la captura periodico.jpg del proyecto inicial. El estilo es libre, y las fotos que se necesiten las podéis elegir vosotros.

## Enunciado 📒

1. Crear la arquitectura inicial: index.html, carpeta /css y estilos.css dentro de la carpeta /css
2. Enlazar hoja de estilos con el HTML
3. Maquetar la captura que se os da, respentando más o menos la arquitectura de bloques

## Archivos y carpetas 🚀

Encontrarás 1 archivo:
1. periodico.jpg   : Estructura de elementos de referencia para maquetar la página de periódico
