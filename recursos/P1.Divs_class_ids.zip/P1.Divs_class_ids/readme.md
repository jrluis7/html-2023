# Descripción rápida 📋

Tienes que crear varias etiquetas con clases en "index.html" cada una con su propio estilo en el archivo "estilo.css"

## Enunciado 📒

1. Crea una etiqueta con un class="contenedor"  :	dale un ancho de 200px , un alto de 200px y un background rojo 	
2. Crea una etiqueta con un class="item"        : dale un ancho de 400px , un alto de 150px y un background azul 	
3. Crea una etiqueta con un class="icono"       : dale un ancho de 50px  , un alto de 50px y un background amarillo 
4. Crea una etiqueta con un class="menu"        : dale un ancho de 50%   , un alto de 100px y un background azul 	
5. Crea una etiqueta con un class="cookies"     : dale un ancho de 75%   , un alto de 500px y un background morado 
6. Crea una etiqueta con un id="especial"	    : dale un ancho de 100%  , un alto de 100px y un background regro 
7. Crea 3 elementos con la clase="generico"     : dale un ancho de 50px  , un alto de 50px de color verde. 
   Al segundo elemento ponerle id="particular"  : dale un borde de 3px, solido y negro. 
## Archivos y carpetas 🚀

Encontrarás 2 archivos básicos:
1. index.html : Aquí escribes la estructura
2. estilo.css : Aquí van los estilos 

Y 1 carpeta:
3. css  : Aquí está el archivo estilo.css
